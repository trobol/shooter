I got carried away making 3d models animated in 2d.

The gameplay is identical to a 2d shooter but everything is 3d.
You can only move on the x and z axes
